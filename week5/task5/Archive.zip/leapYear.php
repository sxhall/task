<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>判断闰年</title>
	<link rel="stylesheet" type="text/css" href="./leapYear.css" />
</head>
<body>
	<div class="input-box" id="input-box">
		<form method="post" action="" onsubmit="return fullEmpty();">
			<h3>判断闰年</h3>
			<input type="text" name="year" id="year">
			<button type="submit" name="submit">查询</button>
		</form>
	</div>
	<div class="result" id="result"></div>
</body>
<script src="./leapYear.js"></script>
<?php
	if(isset($_POST["year"])) {
		$year = $_POST["year"];
		$r = "";

		//显示输入的年份，并记忆年份
		echo "<script>year.value = '{$year}'</script>";

		//公历闰年判定遵循的规律为：四年一闰，百年不闰，四百年再闰
		if(($year%4 == 0 && $year%100 != 0) || ($year%400 == 0 )) {
			$r = "{$year}年是闰年";
		} else {
			$r = "{$year}年是平年";
		}
		echo "<script>result.innerHTML = '{$r}';</script>";
	}

?>
</html>